# durak-card-game-js
Durak card game on JS

Try it out [https://provalentin.github.io/game.html](https://provalentin.github.io/game.html)
